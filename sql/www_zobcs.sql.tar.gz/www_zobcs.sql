-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 02, 2014 at 10:54 AM
-- Server version: 5.5.37-MariaDB-log
-- PHP Version: 5.4.30-pl0-gentoo

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `www_zobcs`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_bda51c3c` (`group_id`),
  KEY `auth_group_permissions_1e014c8f` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_e4470c6e` (`content_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=103 ;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add permission', 1, 'add_permission'),
(2, 'Can change permission', 1, 'change_permission'),
(3, 'Can delete permission', 1, 'delete_permission'),
(4, 'Can add group', 2, 'add_group'),
(5, 'Can change group', 2, 'change_group'),
(6, 'Can delete group', 2, 'delete_group'),
(7, 'Can add user', 3, 'add_user'),
(8, 'Can change user', 3, 'change_user'),
(9, 'Can delete user', 3, 'delete_user'),
(10, 'Can add content type', 4, 'add_contenttype'),
(11, 'Can change content type', 4, 'change_contenttype'),
(12, 'Can delete content type', 4, 'delete_contenttype'),
(13, 'Can add session', 5, 'add_session'),
(14, 'Can change session', 5, 'change_session'),
(15, 'Can delete session', 5, 'delete_session'),
(16, 'Can add site', 6, 'add_site'),
(17, 'Can change site', 6, 'change_site'),
(18, 'Can delete site', 6, 'delete_site'),
(19, 'Can add keywords', 7, 'add_keywords'),
(20, 'Can change keywords', 7, 'change_keywords'),
(21, 'Can delete keywords', 7, 'delete_keywords'),
(22, 'Can add configs', 8, 'add_configs'),
(23, 'Can change configs', 8, 'change_configs'),
(24, 'Can delete configs', 8, 'delete_configs'),
(25, 'Can add categories', 9, 'add_categories'),
(26, 'Can change categories', 9, 'change_categories'),
(27, 'Can delete categories', 9, 'delete_categories'),
(28, 'Can add repos', 10, 'add_repos'),
(29, 'Can change repos', 10, 'change_repos'),
(30, 'Can delete repos', 10, 'delete_repos'),
(31, 'Can add packages', 11, 'add_packages'),
(32, 'Can change packages', 11, 'change_packages'),
(33, 'Can delete packages', 11, 'delete_packages'),
(34, 'Can add ebuilds', 12, 'add_ebuilds'),
(35, 'Can change ebuilds', 12, 'change_ebuilds'),
(36, 'Can delete ebuilds', 12, 'delete_ebuilds'),
(37, 'Can add emerge options', 13, 'add_emergeoptions'),
(38, 'Can change emerge options', 13, 'change_emergeoptions'),
(39, 'Can delete emerge options', 13, 'delete_emergeoptions'),
(40, 'Can add build jobs', 14, 'add_buildjobs'),
(41, 'Can change build jobs', 14, 'change_buildjobs'),
(42, 'Can delete build jobs', 14, 'delete_buildjobs'),
(43, 'Can add build jobs emerge options', 15, 'add_buildjobsemergeoptions'),
(44, 'Can change build jobs emerge options', 15, 'change_buildjobsemergeoptions'),
(45, 'Can delete build jobs emerge options', 15, 'delete_buildjobsemergeoptions'),
(46, 'Can add build jobs redo', 16, 'add_buildjobsredo'),
(47, 'Can change build jobs redo', 16, 'change_buildjobsredo'),
(48, 'Can delete build jobs redo', 16, 'delete_buildjobsredo'),
(49, 'Can add restrictions', 17, 'add_restrictions'),
(50, 'Can change restrictions', 17, 'change_restrictions'),
(51, 'Can delete restrictions', 17, 'delete_restrictions'),
(52, 'Can add uses', 18, 'add_uses'),
(53, 'Can change uses', 18, 'change_uses'),
(54, 'Can delete uses', 18, 'delete_uses'),
(55, 'Can add build jobs use', 19, 'add_buildjobsuse'),
(56, 'Can change build jobs use', 19, 'change_buildjobsuse'),
(57, 'Can delete build jobs use', 19, 'delete_buildjobsuse'),
(58, 'Can add build logs', 20, 'add_buildlogs'),
(59, 'Can change build logs', 20, 'change_buildlogs'),
(60, 'Can delete build logs', 20, 'delete_buildlogs'),
(61, 'Can add build logs config', 21, 'add_buildlogsconfig'),
(62, 'Can change build logs config', 21, 'change_buildlogsconfig'),
(63, 'Can delete build logs config', 21, 'delete_buildlogsconfig'),
(64, 'Can add build logs emerge options', 22, 'add_buildlogsemergeoptions'),
(65, 'Can change build logs emerge options', 22, 'change_buildlogsemergeoptions'),
(66, 'Can delete build logs emerge options', 22, 'delete_buildlogsemergeoptions'),
(67, 'Can add build logs qa', 23, 'add_buildlogsqa'),
(68, 'Can change build logs qa', 23, 'change_buildlogsqa'),
(69, 'Can delete build logs qa', 23, 'delete_buildlogsqa'),
(70, 'Can add build logs repoman', 24, 'add_buildlogsrepoman'),
(71, 'Can change build logs repoman', 24, 'change_buildlogsrepoman'),
(72, 'Can delete build logs repoman', 24, 'delete_buildlogsrepoman'),
(73, 'Can add build logs use', 25, 'add_buildlogsuse'),
(74, 'Can change build logs use', 25, 'change_buildlogsuse'),
(75, 'Can delete build logs use', 25, 'delete_buildlogsuse'),
(76, 'Can add configs emerge options', 26, 'add_configsemergeoptions'),
(77, 'Can change configs emerge options', 26, 'change_configsemergeoptions'),
(78, 'Can delete configs emerge options', 26, 'delete_configsemergeoptions'),
(79, 'Can add configs metadata', 27, 'add_configsmetadata'),
(80, 'Can change configs metadata', 27, 'change_configsmetadata'),
(81, 'Can delete configs metadata', 27, 'delete_configsmetadata'),
(82, 'Can add ebuilds iuse', 28, 'add_ebuildsiuse'),
(83, 'Can change ebuilds iuse', 28, 'change_ebuildsiuse'),
(84, 'Can delete ebuilds iuse', 28, 'delete_ebuildsiuse'),
(85, 'Can add ebuilds keywords', 29, 'add_ebuildskeywords'),
(86, 'Can change ebuilds keywords', 29, 'change_ebuildskeywords'),
(87, 'Can delete ebuilds keywords', 29, 'delete_ebuildskeywords'),
(88, 'Can add ebuilds metadata', 30, 'add_ebuildsmetadata'),
(89, 'Can change ebuilds metadata', 30, 'change_ebuildsmetadata'),
(90, 'Can delete ebuilds metadata', 30, 'delete_ebuildsmetadata'),
(91, 'Can add ebuilds restrictions', 31, 'add_ebuildsrestrictions'),
(92, 'Can change ebuilds restrictions', 31, 'change_ebuildsrestrictions'),
(93, 'Can delete ebuilds restrictions', 31, 'delete_ebuildsrestrictions'),
(94, 'Can add job types', 32, 'add_jobtypes'),
(95, 'Can change job types', 32, 'change_jobtypes'),
(96, 'Can delete job types', 32, 'delete_jobtypes'),
(97, 'Can add jobs', 33, 'add_jobs'),
(98, 'Can change jobs', 33, 'change_jobs'),
(99, 'Can delete jobs', 33, 'delete_jobs'),
(100, 'Can add logs', 34, 'add_logs'),
(101, 'Can change logs', 34, 'change_logs'),
(102, 'Can delete logs', 34, 'delete_logs');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(128) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `username`, `first_name`, `last_name`, `email`, `password`, `is_staff`, `is_active`, `is_superuser`, `last_login`, `date_joined`) VALUES
(1, 'zorry', '', '', 'zorry@ume.nu', 'pbkdf2_sha256$10000$DNod2LWDz3dn$gN+Z0VklQ8ctrMa/4Xemr8GMjs8hiF4B09RleorIKXs=', 1, 1, 1, '2013-05-24 20:59:44', '2012-12-25 21:17:25');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_fbfc09f1` (`user_id`),
  KEY `auth_user_groups_bda51c3c` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_fbfc09f1` (`user_id`),
  KEY `auth_user_user_permissions_1e014c8f` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `name`, `app_label`, `model`) VALUES
(1, 'permission', 'auth', 'permission'),
(2, 'group', 'auth', 'group'),
(3, 'user', 'auth', 'user'),
(4, 'content type', 'contenttypes', 'contenttype'),
(5, 'session', 'sessions', 'session'),
(6, 'site', 'sites', 'site'),
(7, 'keywords', 'zobcs', 'keywords'),
(8, 'configs', 'zobcs', 'configs'),
(9, 'categories', 'zobcs', 'categories'),
(10, 'repos', 'zobcs', 'repos'),
(11, 'packages', 'zobcs', 'packages'),
(12, 'ebuilds', 'zobcs', 'ebuilds'),
(13, 'emerge options', 'zobcs', 'emergeoptions'),
(14, 'build jobs', 'zobcs', 'buildjobs'),
(15, 'build jobs emerge options', 'zobcs', 'buildjobsemergeoptions'),
(16, 'build jobs redo', 'zobcs', 'buildjobsredo'),
(17, 'restrictions', 'zobcs', 'restrictions'),
(18, 'uses', 'zobcs', 'uses'),
(19, 'build jobs use', 'zobcs', 'buildjobsuse'),
(20, 'build logs', 'zobcs', 'buildlogs'),
(21, 'build logs config', 'zobcs', 'buildlogsconfig'),
(22, 'build logs emerge options', 'zobcs', 'buildlogsemergeoptions'),
(23, 'build logs qa', 'zobcs', 'buildlogsqa'),
(24, 'build logs repoman', 'zobcs', 'buildlogsrepoman'),
(25, 'build logs use', 'zobcs', 'buildlogsuse'),
(26, 'configs emerge options', 'zobcs', 'configsemergeoptions'),
(27, 'configs metadata', 'zobcs', 'configsmetadata'),
(28, 'ebuilds iuse', 'zobcs', 'ebuildsiuse'),
(29, 'ebuilds keywords', 'zobcs', 'ebuildskeywords'),
(30, 'ebuilds metadata', 'zobcs', 'ebuildsmetadata'),
(31, 'ebuilds restrictions', 'zobcs', 'ebuildsrestrictions'),
(32, 'job types', 'zobcs', 'jobtypes'),
(33, 'jobs', 'zobcs', 'jobs'),
(34, 'logs', 'zobcs', 'logs');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_c25c2c28` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('18122c97bbfb09324eb185a33795fe9b', 'NmVmZTQ3Nzk0MDUwM2IyNGQzNjkzZjZlZGUzMjQ1NjQ4NmY0NGFmMTqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n', '2013-06-07 20:58:04'),
('a48aebb281074290e2a20c68021a916b', 'YTA3NzhkMDUyYTNiMWYzOGU3ODgxNTdkZDQ5OWJkYWI4MTJlN2JjYzqAAn1xAS4=\n', '2013-06-14 18:07:07');

-- --------------------------------------------------------

--
-- Table structure for table `django_site`
--

CREATE TABLE IF NOT EXISTS `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `django_site`
--

INSERT INTO `django_site` (`id`, `domain`, `name`) VALUES
(1, 'example.com', 'example.com');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `group_id_refs_id_3cea63fe` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `permission_id_refs_id_a7792de1` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `content_type_id_refs_id_728de91f` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `group_id_refs_id_f0ee9890` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `user_id_refs_id_831107f1` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `permission_id_refs_id_67e79cb` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `user_id_refs_id_f2045483` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
